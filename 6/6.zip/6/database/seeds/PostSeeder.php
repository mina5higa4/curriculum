<?php

use Illuminate\Database\Seeder;

class PostSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        //
        // 入力データ
        $data_in = array(
            1 => '一括登録のテストだよ１', 
            2 => '一括登録のテストだよ２', 
            3 => '一括登録のテストだよ３'
        );
        
        $date_default = date('Y-m-d H:i:s');
        foreach ( $data_in as $user_id => $comment ){
            $param = ['user_id' => $user_id, 'body' => $comment, 'created_at' => $date_default, 'updated_at' => $date_default ];
//            $param = ['user_id' => $user_id, 'body' => $comment ];
//            print $user_id . ":" . $comment . ":" . $created_at . "\n";
            DB::table('posts')->insert($param);
        }
    }
}
