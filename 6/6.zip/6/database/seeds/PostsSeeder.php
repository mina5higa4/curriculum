<?php

use Illuminate\Database\Seeder;

class PostsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        // 入力データ
        $data_in = array(
            7 => 'おはよう', 
            8 => 'こんに', 
            9 => 'こん'
        );
        
        $date_default = date('Y-m-d H:i:s');
        foreach ( $data_in as $user_id => $comment ){
            $param = ['user_id' => $user_id, 'body' => $comment, 'created_at' => $date_default, 'updated_at' => $date_default ];
//            $param = ['user_id' => $user_id, 'body' => $comment ];
//            print $user_id . ":" . $comment . ":" . $created_at . "\n";
            DB::table('posts')->insert($param);
        }
    }
}
