<?php $__env->startSection('content'); ?>
<!--content-->
<div class="container">
    <div class="row"><!--row1-->
        <div class="card-body mb-2 col-md-8 mx-auto bg-white border"><!--card-body1-->
            <h5 class="card-title">ホーム</h5>
            <p class="card-text">なんでもつぶやいていいですよ</p>

            <div class="form-group"><!--form-group-->
                <form action="<?php echo e(action('Admin\SNS_Controller@create')); ?>" method="post" enctype="multipart/form-data">
                <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
    <?php if(count($errors) > 0): ?>
                    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($e); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
    <?php endif; ?>
                <div class="text-right">
                    <div class="col-md-12">
                    <input type="text" class="form-control" name="body" value="<?php echo e(old('body')); ?>">
                    <input type="submit" class="btn btn-primary right" value="つぶやく">
                    </div>
                </div>
            <?php echo e(csrf_field()); ?>

            </form></div><!--/form-group-->
        </div><!--/card-body1-->

        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
         <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if( $user->id == $post->user_id ): ?>
            <div class="card-body mb-2 col-md-8 mx-auto bg-white border"><!--card-body2-->
                    <div class="row"><!--row_2-->
                        <div class="col-md-8 text-left font-weight-bold"><?php echo e($user->name); ?></div>
                        <div class="col-md-4 text-right"><?php echo e($post->created_at); ?></div>

                        <div class="col-md-10 text-left"><?php echo e($post->body); ?></div>
                <?php if( Auth::user()->id == $post->user_id ): ?>
                        <div class="col-md-2 text-right"><a class="text-danger" href="<?php echo e(action('Admin\SNS_Controller@delete', ['id'=>$post->id ])); ?>">削除</a></div>
                <?php endif; ?>
                    </div><!--/row2-->
            </div><!--/card-body2-->
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div><!--/row1-->
</div><!--/container-->
<!--/content-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\6\resources\views/create.blade.php ENDPATH**/ ?>