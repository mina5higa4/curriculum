<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

// 以下を追記することでPosts Modelが扱えるようになる
use App\Post;
use App\User;

// 以下を追記
//use App\History;  // Historyモデルを使えるようにする
use Carbon\Carbon; // 日付操作ライブラリ

class SNS_Controller extends Controller
{
    //
  // 画面に表示するための大切なもの
  public function add()
  {
        // viewの直下のcreate.blade.php o miru
      return view('create');
  }


  // つぶやき登録
  public function create(Request $request)
  {
      // Varidationを行う
      $this->validate($request, Post::$rules);

      $post = new Post;
      $form = $request->all();

      // データベースに保存する
      $post->fill($form);
      $post->save();    // update , insert どっちか判定してくれる

      return redirect('post');
  }

  public function index()
  {
    $user = User::all();    // userデータ全部とれる
    $post = Post::orderBy('created_at', 'desc')->get(); // SQL勝手に実行してとってきて入れてくれる感じ

    return view('create', [ 'posts'=>$post, 'users'=>$user ]);
  }

  public function delete(Request $request)
  {
    $post = Post::find($request->id);
    $post->delete();
    return redirect('post');
  }

}
?>
