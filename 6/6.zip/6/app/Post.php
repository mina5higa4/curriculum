<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Post extends Model
{
    // 外から書けないように
    protected $guarded = array('id');

    // validation
    // いまどうしてる？が「空欄の場合」と「255文字を超える場合」は、つぶやけないこと。
    public static $rules = array( 
        'body' => [ 'required', 'max:255', 'string']
    );
    use SoftDeletes ;
}
?>
