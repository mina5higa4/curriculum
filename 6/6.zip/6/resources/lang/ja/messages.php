<?php

return [
    'Login' => 'ログイン',
    'E-Mail Address' => 'メールアドレス',
    'Password' => 'パスワード',
    'Remember Me' => 'ログイン情報を記憶する',
];
?>
