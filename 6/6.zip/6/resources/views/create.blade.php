@extends('layouts.app')

@section('content')
<!--content-->
<div class="container">
    <div class="row"><!--row1-->
        <div class="card-body mb-2 col-md-8 mx-auto bg-white border"><!--card-body1-->
            <h5 class="card-title">ホーム</h5>
            <p class="card-text">なんでもつぶやいていいですよ</p>

            <div class="form-group"><!--form-group-->
                <form action="{{ action('Admin\SNS_Controller@create') }}" method="post" enctype="multipart/form-data">
                <input type="hidden" name="user_id" value="{{Auth::user()->id}}">
    @if (count($errors) > 0)
                    <ul>
        @foreach($errors->all() as $e)
                    <li>{{ $e }}</li>
        @endforeach
                    </ul>
    @endif
                <div class="text-right">
                    <div class="col-md-12">
                    <input type="text" class="form-control" name="body" value="{{ old('body') }}">
                    <input type="submit" class="btn btn-primary right" value="つぶやく">
                    </div>
                </div>
            {{ csrf_field() }}
            </form></div><!--/form-group-->
        </div><!--/card-body1-->

        @foreach( $posts as $post )
         @foreach( $users as $user )
            @if( $user->id == $post->user_id )
            <div class="card-body mb-2 col-md-8 mx-auto bg-white border"><!--card-body2-->
                    <div class="row"><!--row_2-->
                        <div class="col-md-8 text-left font-weight-bold">{{ $user->name }}</div>
                        <div class="col-md-4 text-right">{{ $post->created_at }}</div>

                        <div class="col-md-10 text-left">{{ $post->body }}</div>
                @if( Auth::user()->id == $post->user_id )
                        <div class="col-md-2 text-right"><a class="text-danger" href="{{ action('Admin\SNS_Controller@delete', ['id'=>$post->id ]) }}">削除</a></div>
                @endif
                    </div><!--/row2-->
            </div><!--/card-body2-->
            @endif
        @endforeach
    @endforeach

    </div><!--/row1-->
</div><!--/container-->
<!--/content-->
@endsection
